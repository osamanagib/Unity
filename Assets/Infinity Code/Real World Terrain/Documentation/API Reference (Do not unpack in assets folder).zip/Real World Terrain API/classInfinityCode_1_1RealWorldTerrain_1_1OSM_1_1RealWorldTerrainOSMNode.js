var classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMNode =
[
    [ "lat", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMNode.html#a650605bcface65d8c704b70787a817b2", null ],
    [ "lng", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMNode.html#af90ecedd939a1e14a6af9acae84db0f0", null ]
];