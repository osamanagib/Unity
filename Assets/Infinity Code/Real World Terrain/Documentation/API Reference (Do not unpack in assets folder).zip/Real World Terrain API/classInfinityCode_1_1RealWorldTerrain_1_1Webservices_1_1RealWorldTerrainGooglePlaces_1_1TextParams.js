var classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams =
[
    [ "TextParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a2226d2cbadf2a34b357799c526ff3eda", null ],
    [ "language", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a50de3a87b28dbcef653016468496883e", null ],
    [ "latitude", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#aad3fd39319b33a5bcf494f7c71fc3a12", null ],
    [ "longitude", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a219b222ac0e6e5a8afa8e1aa89077368", null ],
    [ "maxprice", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#acca1c59765e5ee54393024853cc2d01f", null ],
    [ "minprice", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a1a43c77dc962bb43701a446dc3c3cdd7", null ],
    [ "opennow", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a7ad41bfd2ac1ca54da0dd9080e81f546", null ],
    [ "pagetoken", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a7a7515e38fde5cbe0e6f7a2c98484175", null ],
    [ "query", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#ae190f875deb7092452b39e1a6ee7f1c0", null ],
    [ "radius", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#ab557d4b6155aeb034ddcaa065138ef4d", null ],
    [ "types", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a93bd19ba1ceecba4c7c487826ffdad50", null ],
    [ "zagatselected", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#ae89e0426c2a3b4818c366c982451545f", null ],
    [ "lnglat", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#aae2da709be4564a1146821635bb99885", null ]
];