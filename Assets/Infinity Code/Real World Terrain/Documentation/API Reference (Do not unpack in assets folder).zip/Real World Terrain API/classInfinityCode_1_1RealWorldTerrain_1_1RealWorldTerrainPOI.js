var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI =
[
    [ "RealWorldTerrainPOI", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#ade1de81d65dc85bb5b3909d21718ecc8", null ],
    [ "altitude", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#ad31491ce499d36b1503d0d8e7306bf8c", null ],
    [ "title", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#a8cfe0e505995143cf62d781ef8eb9d56", null ],
    [ "x", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#a6837b5fdc8a448ce004f649c1eb18deb", null ],
    [ "y", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#a593eda795bb9d67820202d6fc7cfdf5f", null ]
];