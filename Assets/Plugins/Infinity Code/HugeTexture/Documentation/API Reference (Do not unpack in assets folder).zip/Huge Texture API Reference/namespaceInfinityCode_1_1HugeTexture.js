var namespaceInfinityCode_1_1HugeTexture =
[
    [ "Components", "namespaceInfinityCode_1_1HugeTexture_1_1Components.html", null ],
    [ "HugeTexture2D", "classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html", "classInfinityCode_1_1HugeTexture_1_1HugeTexture2D" ]
];