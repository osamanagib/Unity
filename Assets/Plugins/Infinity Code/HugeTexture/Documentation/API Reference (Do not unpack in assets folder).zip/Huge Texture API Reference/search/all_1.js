var searchData=
[
  ['cols',['cols',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#aa21bafc81ce1565de990d12b6c3ac9e3',1,'InfinityCode::HugeTexture::HugeTexture2D']]]
];
