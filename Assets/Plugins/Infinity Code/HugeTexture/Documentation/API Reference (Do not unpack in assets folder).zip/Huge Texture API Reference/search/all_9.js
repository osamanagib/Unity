var searchData=
[
  ['setpixel',['SetPixel',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#af6304e2fe07d8f734524f3ab1611c42b',1,'InfinityCode::HugeTexture::HugeTexture2D']]],
  ['setpixel32',['SetPixel32',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#a44d5ae35d998f39058c0d2679188bd24',1,'InfinityCode::HugeTexture::HugeTexture2D']]],
  ['setpixels',['SetPixels',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#a483b0b0f8ba33bc57193b53b4c280b01',1,'InfinityCode.HugeTexture.HugeTexture2D.SetPixels(Color[] colors)'],['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#a424d85f812cc22274358899ae3307431',1,'InfinityCode.HugeTexture.HugeTexture2D.SetPixels(int x, int y, int blockWidth, int blockHeight, Color[] colors)']]],
  ['setpixels32',['SetPixels32',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#a5010e65c637787a17f2a86068d040bef',1,'InfinityCode.HugeTexture.HugeTexture2D.SetPixels32(Color32[] colors)'],['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#a5a718deefc601a1054c7fae4652089f3',1,'InfinityCode.HugeTexture.HugeTexture2D.SetPixels32(int x, int y, int blockWidth, int blockHeight, Color32[] colors)']]]
];
