var searchData=
[
  ['rows',['rows',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#aaaedf95db890f4febf5375641c30cf7a',1,'InfinityCode::HugeTexture::HugeTexture2D']]]
];
