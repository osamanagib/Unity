var searchData=
[
  ['pagesize',['pageSize',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#a420887da12a2185667a5265eaaf90ecf',1,'InfinityCode::HugeTexture::HugeTexture2D']]]
];
