var searchData=
[
  ['encodetojpg',['EncodeToJPG',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#ac4e5fdd45486e23f9bfeaef506f778cf',1,'InfinityCode::HugeTexture::HugeTexture2D']]],
  ['encodetopng',['EncodeToPNG',['../classInfinityCode_1_1HugeTexture_1_1HugeTexture2D.html#a38a8a4eb78968357fa4e21607e5517ae',1,'InfinityCode::HugeTexture::HugeTexture2D']]]
];
